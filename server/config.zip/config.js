module.exports = {
    NODE_ENV: process.env.NODE_ENV || 'development',
    HOST: process.env.HOST || '127.0.0.1',
    PORT: process.env.PORT || 4000,
    URLWOO:process.env.URL||'https://bimyou.online/tienda',
    CONSUMERKEY:process.env.CONSUMERKEY||'ck_f4bbc5b7aa79036fb7b4a9817fa312adb9c9731a',
    CONSUMERSECTRET:process.env.CONSUMERSECTRET||'cs_cc67e391db0c94bc4904b2570a0d47b560db54d2'
  }